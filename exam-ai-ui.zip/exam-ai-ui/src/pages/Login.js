import { useState, useEffect } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function Login() {
  const [data, setData] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState("");
  const [mounted, setMounted] = useState(false);
  const navigate = useNavigate();

 // Login.jsx useEffect should be ONLY this:
useEffect(() => { 
  setMounted(true); 
}, []);

  const handleLogin = async () => {
    if (!data.email || !data.password) {
      alert("Please fill all fields");
      return;
    }
    try {
      setLoading(true);
      const res = await API.post("/auth/login", data);
      localStorage.setItem("token", res.data.token);
      navigate("/chat");
    } catch (err) {
      console.error(err);
      alert("Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => { if (e.key === "Enter") handleLogin(); };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .login-root {
          min-height: 100vh;
          background: #f5f5f0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
          padding: 32px 16px;
        }

        .login-root::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(#10a37f0a 1px, transparent 1px),
            linear-gradient(90deg, #10a37f0a 1px, transparent 1px);
          background-size: 48px 48px;
          pointer-events: none;
        }

        .shape-tl {
          position: absolute; top: -60px; left: -60px;
          width: 260px; height: 260px; border-radius: 50%;
          background: radial-gradient(circle, #10a37f14 0%, transparent 70%);
          pointer-events: none;
        }
        .shape-br {
          position: absolute; bottom: -80px; right: -60px;
          width: 320px; height: 320px; border-radius: 50%;
          background: radial-gradient(circle, #10a37f0e 0%, transparent 70%);
          pointer-events: none;
        }

        .card-wrap {
          opacity: 0;
          transform: translateY(22px);
          transition: opacity 0.5s ease, transform 0.5s ease;
        }
        .card-wrap.vis { opacity: 1; transform: translateY(0); }

        .card {
          position: relative; z-index: 1;
          background: #ffffff;
          border: 1px solid #e8e8e3;
          border-radius: 20px;
          padding: 38px 34px 32px;
          width: 400px;
          max-width: calc(100vw - 32px);
          box-shadow: 0 2px 40px #00000009, 0 1px 4px #0000000a;
        }

        .card::before {
          content: '';
          position: absolute;
          top: 0; left: 50%;
          transform: translateX(-50%);
          width: 64px; height: 2.5px;
          background: #10a37f;
          border-radius: 0 0 4px 4px;
        }

        .brand {
          display: flex; align-items: center;
          justify-content: center; gap: 10px;
          margin-bottom: 26px;
        }
        .brand-icon {
          width: 36px; height: 36px;
          border-radius: 10px; background: #10a37f;
          display: flex; align-items: center; justify-content: center;
        }
        .brand-name {
          font-size: 19px; font-weight: 600;
          color: #1a1a1a; letter-spacing: -0.3px;
        }

        .heading {
          font-size: 22px; font-weight: 600;
          color: #111; text-align: center;
          letter-spacing: -0.4px; margin-bottom: 5px;
        }
        .subheading {
          font-size: 13px; color: #888;
          text-align: center; margin-bottom: 26px;
        }

        .field-group { display: flex; flex-direction: column; gap: 14px; margin-bottom: 20px; }

        .field { position: relative; }
        .field-label {
          display: block; font-size: 11.5px; font-weight: 500;
          color: #aaa; margin-bottom: 6px;
          letter-spacing: 0.5px; text-transform: uppercase;
          transition: color 0.2s;
        }
        .field.active .field-label { color: #10a37f; }

        .field-input {
          width: 100%; padding: 11px 14px;
          background: #fafaf8;
          border: 1.5px solid #e8e8e3;
          border-radius: 10px; color: #111;
          font-family: 'DM Sans', sans-serif; font-size: 14px;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
          caret-color: #10a37f;
        }
        .field-input::placeholder { color: #c0c0b8; }
        .field-input:focus {
          background: #fff;
          border-color: #10a37f;
          box-shadow: 0 0 0 3.5px #10a37f1a;
        }

        .forgot {
          text-align: right; margin-top: -6px;
        }
        .forgot-link {
          font-size: 12px; color: #10a37f; font-weight: 500;
          cursor: pointer; background: none; border: none;
          font-family: 'DM Sans', sans-serif; padding: 0;
          transition: color 0.15s;
        }
        .forgot-link:hover { color: #0e9270; }

        .btn-login {
          width: 100%; padding: 12px;
          background: #10a37f; color: #fff;
          border: none; border-radius: 10px;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px; font-weight: 500; cursor: pointer;
          transition: background 0.2s, transform 0.15s, box-shadow 0.2s;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          box-shadow: 0 2px 12px #10a37f30;
        }
        .btn-login:hover:not(:disabled) {
          background: #0e9270;
          box-shadow: 0 4px 18px #10a37f40;
        }
        .btn-login:active:not(:disabled) { transform: scale(0.98); }
        .btn-login:disabled { opacity: 0.6; cursor: not-allowed; }

        @keyframes spin { to { transform: rotate(360deg); } }
        .spinner {
          width: 15px; height: 15px;
          border: 2px solid #ffffff55;
          border-top-color: #fff;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        .divider {
          display: flex; align-items: center; gap: 10px; margin: 20px 0;
        }
        .divider-line { flex: 1; height: 1px; background: #eeeee8; }
        .divider-text { font-size: 11.5px; color: #bbb; }

        .btn-google {
          width: 100%; padding: 11px 14px;
          background: #fff; border: 1.5px solid #e8e8e3;
          border-radius: 10px; color: #444;
          font-family: 'DM Sans', sans-serif; font-size: 13.5px;
          cursor: pointer; display: flex; align-items: center;
          justify-content: center; gap: 10px;
          transition: background 0.2s, border-color 0.2s, box-shadow 0.2s;
        }
        .btn-google:hover {
          background: #fafafa; border-color: #d8d8d0;
          box-shadow: 0 1px 6px #0000000a;
        }
        .btn-google:active { transform: scale(0.98); }

        .footer {
          text-align: center; margin-top: 22px;
          font-size: 13px; color: #aaa;
        }
        .footer-link {
          color: #10a37f; font-weight: 500; cursor: pointer;
          background: none; border: none;
          font-family: 'DM Sans', sans-serif; font-size: 13px;
          padding: 0; transition: color 0.15s;
        }
        .footer-link:hover { color: #0e9270; }

        .terms {
          margin-top: 20px; font-size: 11px; color: #bbb;
          text-align: center; max-width: 320px; line-height: 1.7;
        }
        .terms a { color: #aaa; text-decoration: underline; text-underline-offset: 2px; }
      `}</style>

      <div className="login-root">
        <div className="shape-tl" />
        <div className="shape-br" />

        <div className={`card-wrap ${mounted ? "vis" : ""}`}>
          <div className="card">

            <div className="brand">
              <div className="brand-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                    stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <span className="brand-name">ExamAI</span>
            </div>

            <h1 className="heading">Welcome back</h1>
            <p className="subheading">Sign in to your account to continue</p>

            <button className="btn-google">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Continue with Google
            </button>

            <div className="divider">
              <div className="divider-line" />
              <span className="divider-text">or sign in with email</span>
              <div className="divider-line" />
            </div>

            <div className="field-group">
              <div className={`field ${focused === "email" ? "active" : ""}`}>
                <label className="field-label">Email address</label>
                <input
                  type="email"
                  className="field-input"
                  placeholder="you@example.com"
                  value={data.email}
                  onFocus={() => setFocused("email")}
                  onBlur={() => setFocused("")}
                  onChange={(e) => setData({ ...data, email: e.target.value })}
                  onKeyDown={handleKeyDown}
                />
              </div>

              <div className={`field ${focused === "password" ? "active" : ""}`}>
                <label className="field-label">Password</label>
                <input
                  type="password"
                  className="field-input"
                  placeholder="••••••••"
                  value={data.password}
                  onFocus={() => setFocused("password")}
                  onBlur={() => setFocused("")}
                  onChange={(e) => setData({ ...data, password: e.target.value })}
                  onKeyDown={handleKeyDown}
                />
              </div>

              <div className="forgot">
                <button className="forgot-link">Forgot password?</button>
              </div>
            </div>

            <button className="btn-login" onClick={handleLogin} disabled={loading}>
              {loading ? (
                <><span className="spinner" /> Signing in…</>
              ) : (
                "Sign in"
              )}
            </button>

            <p className="footer">
              Don&apos;t have an account?{" "}
          <button className="footer-link" onClick={() => navigate("/register", { replace: true })}>
                Create one
              </button>
            </p>
          </div>

          <p className="terms">
            By continuing, you agree to our{" "}
            <a href="#">Terms of Service</a> and{" "}
            <a href="#">Privacy Policy</a>.
          </p>
        </div>
      </div>
    </>
  );
}

export default Login;
