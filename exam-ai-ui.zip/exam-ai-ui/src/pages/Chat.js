import { useState, useRef, useEffect } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

// ── MCQ Parser ─────────────────────────────────────────────────────────────
function parseMCQs(text) {
  const blocks = text.split(/Q\d+\./g).filter(Boolean);
  return blocks.map((block) => {
    const lines = block.trim().split("\n").filter(Boolean);
    const question = lines[0]?.trim() ?? "";
    const options = [];
    
    let answer = "";
    let explanation = "";
    for (const line of lines.slice(1)) {
      if (/^[A-D]\)/.test(line)) options.push(line.trim());
      else if (line.startsWith("Answer:")) answer = line.replace("Answer:", "").trim();
      else if (line.startsWith("Explanation:")) explanation = line.replace("Explanation:", "").trim();
    }
    return { question, options, answer, explanation };
  }).filter(q => q.question && q.options.length > 0);
}

// ── MCQ Card Component ─────────────────────────────────────────────────────
function MCQCard({ mcq, index }) {
  const [selected, setSelected] = useState(null);
  const correct = mcq.answer?.charAt(0);
  return (
    <div style={{
      border: "1px solid #e8e8e3", borderRadius: 12, padding: "16px 18px",
      marginBottom: 12, background: "#fafaf8"
    }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: "#10a37f", marginBottom: 8 }}>
        Q{index + 1}
      </div>
      <div style={{ fontSize: 14, color: "#111", marginBottom: 12, lineHeight: 1.6 }}>
        {mcq.question}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {mcq.options.map((opt, i) => {
          const letter = opt.charAt(0);
          const isSelected = selected === letter;
          const isCorrect = letter === correct;
          let bg = "#fff", border = "1px solid #e8e8e3", color = "#333";
          if (selected) {
            if (isCorrect)  { bg = "#f0faf6"; border = "1px solid #10a37f"; color = "#0e9270"; }
            else if (isSelected) { bg = "#fff5f5"; border = "1px solid #ff4d4f"; color = "#cc0000"; }
          }
          return (
            <button key={i} onClick={() => !selected && setSelected(letter)}
              style={{
                textAlign: "left", padding: "9px 14px", borderRadius: 8,
                background: bg, border, color,
                fontFamily: "inherit", fontSize: 13.5, cursor: selected ? "default" : "pointer",
                transition: "all 0.15s"
              }}>
              {opt}
            </button>
          );
        })}
      </div>
      {selected && mcq.explanation && (
        <div style={{ marginTop: 10, fontSize: 12.5, color: "#666",
          background: "#f5f5f0", borderRadius: 8, padding: "8px 12px" }}>
          💡 {mcq.explanation}
        </div>
      )}
    </div>
  );
}

// ── Intent Badge ───────────────────────────────────────────────────────────
function IntentBadge({ intent, examType }) {
  const intentLabels = {
    CONCEPT_EXPLAIN: { label: "Concept", color: "#6366f1", bg: "#eef2ff" },
    QUIZ_MCQ:        { label: "Quiz",    color: "#10a37f", bg: "#f0faf6" },
    EXAM_STRATEGY:   { label: "Strategy",color: "#f59e0b", bg: "#fffbeb" },
    CURRENT_AFFAIRS: { label: "Current Affairs", color: "#3b82f6", bg: "#eff6ff" },
    RESOURCES:       { label: "Resources", color: "#8b5cf6", bg: "#f5f3ff" },
    GENERAL:         { label: "General", color: "#888", bg: "#f5f5f0" },
  };
  const examColors = {
    UPSC: "#ef4444", SSC: "#f97316", BANKING: "#3b82f6", MPSC: "#8b5cf6", GENERAL: "#aaa"
  };
  const intentData = intentLabels[intent] ?? intentLabels.GENERAL;
  return (
    <div style={{ display: "flex", gap: 6, marginBottom: 6 }}>
      <span style={{
        fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 99,
        background: intentData.bg, color: intentData.color, letterSpacing: 0.3
      }}>{intentData.label}</span>
      {examType && examType !== "GENERAL" && (
        <span style={{
          fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 99,
          background: "#fff", border: `1px solid ${examColors[examType] ?? "#aaa"}`,
          color: examColors[examType] ?? "#aaa", letterSpacing: 0.3
        }}>{examType}</span>
      )}
    </div>
  );
}

// ── Smart Message Renderer ─────────────────────────────────────────────────
function SmartMessage({ text, intent }) {
  if (intent === "QUIZ_MCQ") {
    const mcqs = parseMCQs(text);
    if (mcqs.length > 0) {
      return (
        <div>
          {mcqs.map((mcq, i) => <MCQCard key={i} mcq={mcq} index={i} />)}
        </div>
      );
    }
  }
  return <div style={{ fontSize: 14, lineHeight: 1.75, color: "#1a1a1a", whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{text}</div>;
}

// ── Exam Onboarding Modal ──────────────────────────────────────────────────
function ExamOnboarding({ onSelect }) {
  const exams = [
    { key: "UPSC",    label: "UPSC", sub: "IAS / IPS / IFS", color: "#ef4444" },
    { key: "SSC",     label: "SSC",  sub: "CGL / CHSL / GD", color: "#f97316" },
    { key: "BANKING", label: "Banking", sub: "IBPS / SBI / RBI", color: "#3b82f6" },
    { key: "MPSC",    label: "MPSC", sub: "Rajyaseva / MH",  color: "#8b5cf6" },
  ];
  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)",
      display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100
    }}>
      <div style={{
        background: "#fff", borderRadius: 20, padding: "36px 32px",
        maxWidth: 440, width: "90%", boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
        fontFamily: "'DM Sans', sans-serif"
      }}>
        <div style={{ fontSize: 22, fontWeight: 700, color: "#111", marginBottom: 6 }}>
          Which exam are you preparing for?
        </div>
        <div style={{ fontSize: 13.5, color: "#888", marginBottom: 24 }}>
          I'll tailor every answer specifically for your exam.
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {exams.map(e => (
            <button key={e.key} onClick={() => onSelect(e.key)}
              style={{
                padding: "18px 14px", borderRadius: 14, border: `2px solid ${e.color}22`,
                background: `${e.color}08`, cursor: "pointer",
                fontFamily: "inherit", textAlign: "left", transition: "all 0.15s"
              }}
              onMouseEnter={ev => ev.currentTarget.style.background = `${e.color}15`}
              onMouseLeave={ev => ev.currentTarget.style.background = `${e.color}08`}
            >
              <div style={{ fontSize: 18, fontWeight: 700, color: e.color }}>{e.label}</div>
              <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>{e.sub}</div>
            </button>
          ))}
        </div>
        <button onClick={() => onSelect("GENERAL")}
          style={{
            marginTop: 16, width: "100%", padding: "12px",
            background: "none", border: "1px solid #e8e8e3", borderRadius: 10,
            fontFamily: "inherit", fontSize: 13, color: "#888", cursor: "pointer"
          }}>
          Skip — general preparation
        </button>
      </div>
    </div>
  );
}

// ── Main Chat Component ────────────────────────────────────────────────────
function Chat() {
  const navigate = useNavigate();

  const [input, setInput]           = useState("");
  const [messages, setMessages]     = useState([]);
  const [history, setHistory]       = useState([]);
  const [loading, setLoading]       = useState(false);
  const [examType, setExamType]     = useState(null); // user's exam preference
  const [showOnboarding, setShowOnboarding] = useState(false);

  const bottomRef   = useRef(null);
  const textareaRef = useRef(null);

  // Show onboarding if no exam type saved
  useEffect(() => {
    const saved = localStorage.getItem("examType");
    if (saved) setExamType(saved);
    else setShowOnboarding(true);
    fetchHistory();
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const fetchHistory = async () => {
    try {
      const res = await API.get("/ai/history");
      setHistory(res.data);
    } catch (err) {
      console.error("Error fetching history", err);
    }
  };

  const handleExamSelect = (type) => {
    setExamType(type);
    localStorage.setItem("examType", type);
    setShowOnboarding(false);
  };

  const adjustTextarea = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 160) + "px";
  };

// In Chat.js, replace the existing handleLogout with:
const handleLogout = () => {
  // Clear all localStorage items
  localStorage.removeItem("token");
  localStorage.removeItem("examType");
  localStorage.removeItem("userData"); // if you have any other items
  
  // Navigate to login and replace the history entry
  navigate("/login", { replace: true });
};
  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const text = input.trim();
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    setMessages(prev => [...prev, { role: "user", text }]);
    setLoading(true);

    try {
      const res = await API.post("/ai/ask", {
        question: text,
        examType: examType ?? "GENERAL",
      });

      // res.data is now an AIResponse: { answer, intent, examType, fromCache }
      const { answer, intent, examType: detectedExam } = res.data;

      setMessages(prev => [...prev, {
        role: "ai",
        text: answer,
        intent,
        examType: detectedExam,
      }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        role: "ai",
        text: "⚠️ Something went wrong. Please try again.",
        intent: "GENERAL",
        examType: examType,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const examColors = { UPSC: "#ef4444", SSC: "#f97316", BANKING: "#3b82f6", MPSC: "#8b5cf6", GENERAL: "#10a37f" };
  const accentColor = examColors[examType] ?? "#10a37f";

  const suggestions = {
    UPSC:    ["Explain Article 356", "UPSC strategy 2025", "Indian Polity MCQ", "Recent constitutional amendments"],
    SSC:     ["SSC CGL math tips", "English grammar MCQ", "GK for SSC", "SSC CGL strategy"],
    BANKING: ["Banking awareness MCQ", "RBI monetary policy", "Reasoning shortcut tips", "SBI PO strategy"],
    MPSC:    ["Maharashtra geography", "Rajyaseva strategy", "MPSC polity MCQ", "Maharashtra history"],
    GENERAL: ["Explain a concept", "Quiz me on history", "Prepare a study plan", "Best books for exams"],
  };
  const currentSuggestions = suggestions[examType ?? "GENERAL"] ?? suggestions.GENERAL;

  const isEmpty = messages.length === 0;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        .chat-root { display: flex; height: 100vh; background: #f5f5f0; font-family: 'DM Sans', sans-serif; overflow: hidden; }
        .sidebar { width: 260px; background: #fff; border-right: 1px solid #e8e8e3; display: flex; flex-direction: column; flex-shrink: 0; }
        .sidebar-header { padding: 18px 16px 14px; border-bottom: 1px solid #f0f0eb; display: flex; align-items: center; gap: 10px; }
        .brand-icon { width: 30px; height: 30px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .brand-name { font-size: 16px; font-weight: 600; color: #1a1a1a; letter-spacing: -0.2px; }
        .new-chat-btn { margin: 12px 12px 8px; padding: 9px 14px; background: #f5f5f0; border: 1px solid #e8e8e3; border-radius: 10px; font-family: 'DM Sans', sans-serif; font-size: 13px; font-weight: 500; color: #444; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: background 0.15s; }
        .new-chat-btn:hover { background: #eeeee8; }
        .sidebar-item { margin: 1px 8px; padding: 8px 10px; border-radius: 8px; font-size: 13px; color: #555; cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: background 0.15s; }
        .sidebar-item:hover { background: #f5f5f0; color: #222; }
        .sidebar-footer { margin-top: auto; padding: 12px; border-top: 1px solid #f0f0eb; display: flex; align-items: center; gap: 10px; }
        .avatar { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 600; color: #fff; flex-shrink: 0; }
        .main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
        .topbar { height: 54px; background: #fff; border-bottom: 1px solid #e8e8e3; display: flex; align-items: center; padding: 0 20px; gap: 10px; flex-shrink: 0; }
        .topbar-title { font-size: 14px; font-weight: 500; color: #333; }
        .messages-area { flex: 1; overflow-y: auto; padding: 24px 0 12px; scroll-behavior: smooth; }
        .messages-area::-webkit-scrollbar { width: 4px; }
        .messages-area::-webkit-scrollbar-thumb { background: #ddd; border-radius: 99px; }
        .message-row { display: flex; gap: 12px; padding: 6px 24px; max-width: 820px; margin: 0 auto; width: 100%; animation: fadeUp 0.25s ease; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        .msg-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0; margin-top: 2px; }
        .msg-avatar.user { background: #1a1a1a; color: #fff; }
        .msg-content { flex: 1; min-width: 0; }
        .msg-name { font-size: 12px; font-weight: 600; color: #aaa; margin-bottom: 4px; }
        .typing-dots { display: flex; align-items: center; gap: 4px; padding: 4px 0; }
        .typing-dots span { width: 7px; height: 7px; border-radius: 50%; opacity: 0.5; animation: bounce 1.2s infinite; }
        .typing-dots span:nth-child(2) { animation-delay: 0.2s; }
        .typing-dots span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes bounce { 0%, 80%, 100% { transform: translateY(0); opacity: 0.4; } 40% { transform: translateY(-5px); opacity: 1; } }
        .empty-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 40px 24px; animation: fadeUp 0.4s ease; }
        .empty-icon { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; margin-bottom: 18px; }
        .empty-title { font-size: 22px; font-weight: 600; color: #111; margin-bottom: 6px; letter-spacing: -0.3px; }
        .empty-sub { font-size: 13.5px; color: #999; margin-bottom: 28px; }
        .suggestions { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; width: 100%; max-width: 520px; }
        .suggestion-card { padding: 12px 14px; background: #fff; border: 1px solid #e8e8e3; border-radius: 12px; cursor: pointer; text-align: left; font-family: 'DM Sans', sans-serif; transition: border-color 0.15s, box-shadow 0.15s; }
        .suggestion-card:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        .suggestion-label { font-size: 13px; font-weight: 500; color: #333; }
        .input-bar { padding: 12px 20px 16px; background: #fff; border-top: 1px solid #e8e8e3; flex-shrink: 0; }
        .input-inner { max-width: 820px; margin: 0 auto; background: #fafaf8; border: 1.5px solid #e8e8e3; border-radius: 14px; display: flex; align-items: flex-end; gap: 10px; padding: 10px 12px 10px 16px; transition: border-color 0.2s, box-shadow 0.2s; }
        .chat-textarea { flex: 1; resize: none; border: none; outline: none; background: transparent; font-family: 'DM Sans', sans-serif; font-size: 14px; color: #111; line-height: 1.6; min-height: 24px; max-height: 160px; }
        .chat-textarea::placeholder { color: #bbb; }
        .send-btn { width: 34px; height: 34px; border-radius: 9px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: opacity 0.15s, transform 0.1s; }
        .send-btn:hover:not(:disabled) { filter: brightness(0.9); }
        .send-btn:active:not(:disabled) { transform: scale(0.92); }
        .send-btn:disabled { opacity: 0.35; cursor: not-allowed; }
        .input-hint { text-align: center; font-size: 11px; color: #ccc; margin-top: 8px; max-width: 820px; margin-left: auto; margin-right: auto; }
        .exam-change-btn { font-size: 11px; padding: 3px 9px; border-radius: 99px; border: 1px solid; cursor: pointer; background: none; font-family: 'DM Sans', sans-serif; font-weight: 500; margin-left: auto; }
      `}</style>

      {showOnboarding && <ExamOnboarding onSelect={handleExamSelect} />}

      <div className="chat-root">
        {/* Sidebar */}
        <aside className="sidebar">
          <div className="sidebar-header">
            <div className="brand-icon" style={{ background: accentColor }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                  stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="brand-name">ExamAI</span>
          </div>

          <button className="new-chat-btn" onClick={() => setMessages([])}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M12 5v14M5 12h14" stroke="#666" strokeWidth="2.2" strokeLinecap="round"/>
            </svg>
            New chat
          </button>

          {/* History */}
          {history.map((item) => (
            <div key={item.id} className="sidebar-item"
              onClick={() => setMessages([
                { role: "user", text: item.question },
                { role: "ai", text: item.answer, intent: item.intent, examType: item.examType },
              ])}>
              {item.question}
            </div>
          ))}

          {/* Footer */}
       
<div className="sidebar-footer">
  <div className="avatar" style={{ background: accentColor }}>U</div>
  <div style={{ flex: 1 }}>
    <div style={{ fontSize: 13, fontWeight: 500, color: "#333" }}>Student</div>
    <div style={{ fontSize: 11, color: "#aaa" }}>
      {examType ?? "GENERAL"} prep
    </div>
  </div>
  <button onClick={() => setShowOnboarding(true)}
    style={{ fontSize: 11, background: "none", border: "none",
      color: accentColor, cursor: "pointer", fontFamily: "inherit" }}>
    Switch
  </button>
  {/* Add Logout Button */}
  <button onClick={handleLogout}
    style={{ fontSize: 11, background: "none", border: "none",
      color: "#e84040", cursor: "pointer", fontFamily: "inherit", marginLeft: 8 }}>
    Logout
  </button>
</div>
        </aside>

        {/* Main */}
        <main className="main">
          <div className="topbar">
            <span className="topbar-title">Chat</span>
            <span style={{
              marginLeft: "auto", padding: "4px 10px",
              background: `${accentColor}15`, border: `1px solid ${accentColor}44`,
              borderRadius: 99, fontSize: 11.5, fontWeight: 600, color: accentColor
            }}>
              {examType ?? "General"} Mode
            </span>
          </div>

          {isEmpty ? (
            <div className="empty-state">
              <div className="empty-icon" style={{ background: accentColor }}>
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                    stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h2 className="empty-title">What can I help you study?</h2>
              <p className="empty-sub">Tailored answers for {examType ?? "your"} exam preparation.</p>
              <div className="suggestions">
                {currentSuggestions.map((s, i) => (
                  <button key={i} className="suggestion-card"
                    style={{ borderColor: `${accentColor}22` }}
                    onClick={() => { setInput(s); textareaRef.current?.focus(); }}>
                    <div className="suggestion-label" style={{ color: accentColor }}>{s}</div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="messages-area">
              {messages.map((msg, i) => (
                <div key={i} className="message-row">
                  <div className="msg-avatar" style={
                    msg.role === "user"
                      ? { background: "#1a1a1a", color: "#fff" }
                      : { background: accentColor, color: "#fff" }
                  }>
                    {msg.role === "user" ? "U" : (
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                          stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </div>
                  <div className="msg-content">
                    <div className="msg-name">{msg.role === "user" ? "You" : "ExamAI"}</div>
                    {msg.role === "ai" && msg.intent && (
                      <IntentBadge intent={msg.intent} examType={msg.examType} />
                    )}
                    {msg.role === "user"
                      ? <div style={{ fontSize: 14, lineHeight: 1.75, color: "#1a1a1a", whiteSpace: "pre-wrap" }}>{msg.text}</div>
                      : <SmartMessage text={msg.text} intent={msg.intent} />
                    }
                  </div>
                </div>
              ))}

              {loading && (
                <div className="message-row">
                  <div className="msg-avatar" style={{ background: accentColor, color: "#fff" }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                      <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                        stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="msg-content">
                    <div className="msg-name">ExamAI</div>
                    <div className="typing-dots">
                      <span style={{ background: accentColor }} />
                      <span style={{ background: accentColor }} />
                      <span style={{ background: accentColor }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          )}

          {/* Input */}
          <div className="input-bar">
            <div className="input-inner" style={{ "--accent": accentColor }}>
              <textarea ref={textareaRef} className="chat-textarea"
                placeholder={`Ask anything about ${examType ?? "your exam"}…`}
                value={input} rows={1}
                onChange={e => { setInput(e.target.value); adjustTextarea(); }}
                onKeyDown={handleKeyDown}
                style={{ caretColor: accentColor }}
              />
              <button className="send-btn" onClick={sendMessage}
                disabled={!input.trim() || loading}
                style={{ background: accentColor }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                  <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"
                    stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
            <div className="input-hint">Enter to send · Shift+Enter for new line</div>
          </div>
        </main>
      </div>
    </>
  );
}

export default Chat;
