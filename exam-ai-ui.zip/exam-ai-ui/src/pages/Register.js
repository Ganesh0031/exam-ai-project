import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api"; // Make sure this path matches your project structure

const Register = () => {
  const [data, setData] = useState({ 
    name: "", 
    email: "", 
    password: "", 
    confirm: "" 
  });
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState("");
  const [mounted, setMounted] = useState(false);
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const navigate = useNavigate();

useEffect(() => { 
  setMounted(true);
  // If token exists but user clicked "Create one", 
  // they want a new account — clear the old token
  localStorage.removeItem("token");
  localStorage.removeItem("examType");
}, []);  // ← Remove [navigate] dependency, remove token check entirely
  const validate = () => {
    const e = {};
    if (!data.name.trim()) e.name = "Name is required";
    if (!data.email.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Enter a valid email";
    if (data.password.length < 8) e.password = "At least 8 characters";
    if (data.password !== data.confirm) e.confirm = "Passwords don't match";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = async () => {
    setApiError("");
    if (!validate()) return;
    
    try {
      setLoading(true);
      
      // Call the actual API endpoint
      const response = await API.post("/auth/register", {
        name: data.name,
        email: data.email,
        password: data.password
      });
      
  // In Register.js, update the successful registration navigation:
if (response.data === "User Registered" || response.status === 200) {
  try {
    const loginResponse = await API.post("/auth/login", {
      email: data.email,
      password: data.password
    });
    
    if (loginResponse.data.token) {
      localStorage.setItem("token", loginResponse.data.token);
      // Use replace to prevent going back to registration
      navigate("/chat", { replace: true });
    } else {
      navigate("/login", { replace: true });
    }
  } catch (loginErr) {
    console.error("Auto-login failed:", loginErr);
    navigate("/login", { replace: true });
  }
}
    } catch (err) {
      console.error("Registration error:", err);
      if (err.response?.data) {
        // Handle different error formats
        if (typeof err.response.data === 'string') {
          setApiError(err.response.data);
        } else if (err.response.data.message) {
          setApiError(err.response.data.message);
        } else {
          setApiError("Registration failed. Please try again.");
        }
      } else if (err.message === "Network Error") {
        setApiError("Network error. Please check your connection.");
      } else {
        setApiError("Registration failed. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const field = (id, label, type, placeholder) => (
    <div className={`field ${focused === id ? "active" : ""} ${errors[id] ? "error" : ""}`}>
      <label className="field-label">{label}</label>
      <input
        type={type}
        className="field-input"
        placeholder={placeholder}
        value={data[id]}
        onFocus={() => { 
          setFocused(id); 
          setErrors((p) => ({ ...p, [id]: "" }));
          setApiError("");
        }}
        onBlur={() => setFocused("")}
        onChange={(e) => setData({ ...data, [id]: e.target.value })}
      />
      {errors[id] && <span className="field-error">{errors[id]}</span>}
    </div>
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .reg-root {
          min-height: 100vh;
          background: #f5f5f0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
          padding: 32px 16px;
        }

        /* Subtle geometric background */
        .reg-root::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(#10a37f0a 1px, transparent 1px),
            linear-gradient(90deg, #10a37f0a 1px, transparent 1px);
          background-size: 48px 48px;
          pointer-events: none;
        }

        /* Corner accent shapes */
        .shape-tl {
          position: absolute; top: -60px; left: -60px;
          width: 260px; height: 260px;
          border-radius: 50%;
          background: radial-gradient(circle, #10a37f14 0%, transparent 70%);
          pointer-events: none;
        }
        .shape-br {
          position: absolute; bottom: -80px; right: -60px;
          width: 320px; height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, #10a37f0e 0%, transparent 70%);
          pointer-events: none;
        }

        /* Card slide-up */
        .card-wrap {
          opacity: 0;
          transform: translateY(22px);
          transition: opacity 0.5s ease, transform 0.5s ease;
        }
        .card-wrap.vis { opacity: 1; transform: translateY(0); }

        .card {
          position: relative; z-index: 1;
          background: #ffffff;
          border: 1px solid #e8e8e3;
          border-radius: 20px;
          padding: 38px 34px 32px;
          width: 400px;
          max-width: calc(100vw - 32px);
          box-shadow: 0 2px 40px #00000009, 0 1px 4px #0000000a;
        }

        /* Top green accent bar */
        .card::before {
          content: '';
          position: absolute;
          top: 0; left: 50%;
          transform: translateX(-50%);
          width: 64px; height: 2.5px;
          background: #10a37f;
          border-radius: 0 0 4px 4px;
        }

        .brand {
          display: flex; align-items: center;
          justify-content: center; gap: 10px;
          margin-bottom: 26px;
        }
        .brand-icon {
          width: 36px; height: 36px;
          border-radius: 10px;
          background: #10a37f;
          display: flex; align-items: center; justify-content: center;
        }
        .brand-name {
          font-size: 19px; font-weight: 600;
          color: #1a1a1a; letter-spacing: -0.3px;
        }

        .heading {
          font-size: 22px; font-weight: 600;
          color: #111; text-align: center;
          letter-spacing: -0.4px; margin-bottom: 5px;
        }
        .subheading {
          font-size: 13px; color: #888;
          text-align: center; margin-bottom: 26px;
        }

        .field-group { display: flex; flex-direction: column; gap: 14px; margin-bottom: 20px; }

        .field { position: relative; }
        .field-label {
          display: block; font-size: 11.5px; font-weight: 500;
          color: #999; margin-bottom: 6px;
          letter-spacing: 0.5px; text-transform: uppercase;
          transition: color 0.2s;
        }
        .field.active .field-label { color: #10a37f; }
        .field.error .field-label { color: #e84040; }

        .field-input {
          width: 100%; padding: 11px 14px;
          background: #fafaf8;
          border: 1.5px solid #e8e8e3;
          border-radius: 10px; color: #111;
          font-family: 'DM Sans', sans-serif; font-size: 14px;
          outline: none; transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
          caret-color: #10a37f;
        }
        .field-input::placeholder { color: #c0c0b8; }
        .field-input:focus {
          background: #fff;
          border-color: #10a37f;
          box-shadow: 0 0 0 3.5px #10a37f1a;
        }
        .field.error .field-input { border-color: #e8404044; }
        .field.error .field-input:focus { box-shadow: 0 0 0 3.5px #e840401a; }

        .field-error {
          font-size: 11.5px; color: #e84040;
          margin-top: 5px; display: block;
        }

        .api-error {
          background: #fee;
          border: 1px solid #fcc;
          border-radius: 10px;
          padding: 10px 14px;
          margin-bottom: 16px;
          color: #e84040;
          font-size: 12.5px;
          text-align: center;
        }

        .btn-register {
          width: 100%; padding: 12px;
          background: #10a37f; color: #fff;
          border: none; border-radius: 10px;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px; font-weight: 500; cursor: pointer;
          transition: background 0.2s, transform 0.15s, box-shadow 0.2s;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          letter-spacing: 0.1px;
          box-shadow: 0 2px 12px #10a37f30;
        }
        .btn-register:hover:not(:disabled) {
          background: #0e9270;
          box-shadow: 0 4px 18px #10a37f40;
        }
        .btn-register:active:not(:disabled) { transform: scale(0.98); }
        .btn-register:disabled { opacity: 0.6; cursor: not-allowed; }

        @keyframes spin { to { transform: rotate(360deg); } }
        .spinner {
          width: 15px; height: 15px;
          border: 2px solid #ffffff55;
          border-top-color: #fff;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        .divider {
          display: flex; align-items: center; gap: 10px; margin: 20px 0;
        }
        .divider-line { flex: 1; height: 1px; background: #eeeee8; }
        .divider-text { font-size: 11.5px; color: #bbb; }

        .btn-google {
          width: 100%; padding: 11px 14px;
          background: #fff; border: 1.5px solid #e8e8e3;
          border-radius: 10px; color: #444;
          font-family: 'DM Sans', sans-serif; font-size: 13.5px;
          cursor: pointer; display: flex; align-items: center;
          justify-content: center; gap: 10px;
          transition: background 0.2s, border-color 0.2s, box-shadow 0.2s;
        }
        .btn-google:hover {
          background: #fafafa; border-color: #d8d8d0;
          box-shadow: 0 1px 6px #0000000a;
        }
        .btn-google:active { transform: scale(0.98); }

        .footer {
          text-align: center; margin-top: 22px;
          font-size: 13px; color: #aaa;
        }
        .footer-link {
          color: #10a37f; font-weight: 500; cursor: pointer;
          background: none; border: none;
          font-family: 'DM Sans', sans-serif; font-size: 13px;
          padding: 0; transition: color 0.15s;
        }
        .footer-link:hover { color: #0e9270; }

        .terms {
          margin-top: 20px; font-size: 11px;
          color: #bbb; text-align: center; line-height: 1.7;
          max-width: 320px;
        }
        .terms a { color: #aaa; text-decoration: underline; text-underline-offset: 2px; }

        /* Password strength bar */
        .strength-bar {
          height: 3px; border-radius: 99px;
          background: #eeeee8; margin-top: 8px;
          overflow: hidden;
        }
        .strength-fill {
          height: 100%; border-radius: 99px;
          transition: width 0.4s ease, background 0.4s ease;
        }

        /* Success message */
        .success-message {
          background: #e8f5f0;
          border: 1px solid #10a37f;
          border-radius: 10px;
          padding: 10px 14px;
          margin-bottom: 16px;
          color: #10a37f;
          font-size: 12.5px;
          text-align: center;
        }
      `}</style>

      <div className="reg-root">
        <div className="shape-tl" />
        <div className="shape-br" />

        <div className={`card-wrap ${mounted ? "vis" : ""}`}>
          <div className="card">
            {/* Brand */}
            <div className="brand">
              <div className="brand-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                    stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <span className="brand-name">ExamAI</span>
            </div>

            <h1 className="heading">Create your account</h1>
            <p className="subheading">Start learning smarter today</p>

            {/* Google Sign-up (demo) */}
            <button className="btn-google" onClick={() => alert("Google signup coming soon!")}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Sign up with Google
            </button>

            <div className="divider">
              <div className="divider-line" />
              <span className="divider-text">or register with email</span>
              <div className="divider-line" />
            </div>

            {/* API Error Display */}
            {apiError && (
              <div className="api-error">
                ⚠️ {apiError}
              </div>
            )}

            {/* Fields */}
            <div className="field-group">
              {field("name", "Full name", "text", "Jane Smith")}
              {field("email", "Email address", "email", "jane@example.com")}

              {/* Password with strength indicator */}
              <div className={`field ${focused === "password" ? "active" : ""} ${errors.password ? "error" : ""}`}>
                <label className="field-label">Password</label>
                <input
                  type="password"
                  className="field-input"
                  placeholder="Min. 8 characters"
                  value={data.password}
                  onFocus={() => { 
                    setFocused("password"); 
                    setErrors((p) => ({ ...p, password: "" }));
                    setApiError("");
                  }}
                  onBlur={() => setFocused("")}
                  onChange={(e) => setData({ ...data, password: e.target.value })}
                />
                {/* Strength bar */}
                {data.password.length > 0 && (
                  <div className="strength-bar">
                    <div className="strength-fill" style={{
                      width: data.password.length < 6 ? "25%" :
                             data.password.length < 10 ? "55%" : "100%",
                      background: data.password.length < 6 ? "#e84040" :
                                  data.password.length < 10 ? "#f59e0b" : "#10a37f",
                    }} />
                  </div>
                )}
                {errors.password && <span className="field-error">{errors.password}</span>}
              </div>

              {field("confirm", "Confirm password", "password", "Repeat your password")}
            </div>

            {/* CTA */}
            <button className="btn-register" onClick={handleRegister} disabled={loading}>
              {loading ? (
                <><span className="spinner" /> Creating account…</>
              ) : (
                "Create account"
              )}
            </button>

            <p className="footer">
              Already have an account?{" "}
             <button className="footer-link" onClick={() => navigate("/login", { replace: true })}>
                Sign in
              </button>
            </p>
          </div>

          <p className="terms">
            By creating an account you agree to our{" "}
            <a href="#">Terms of Service</a> and{" "}
            <a href="#">Privacy Policy</a>.
          </p>
        </div>
      </div>
    </>
  );
};

export default Register;