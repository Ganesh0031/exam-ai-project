import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Chat from "./pages/Chat";

// Check if token exists and is valid
const isAuthenticated = () => {
  const token = localStorage.getItem("token");
  if (!token) return false;
  
  // Optional: Check token expiration
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    if (payload.exp && payload.exp < Date.now() / 1000) {
      // Token expired
      localStorage.removeItem("token");
      localStorage.removeItem("examType");
      return false;
    }
    return true;
  } catch (e) {
    // Invalid token format
    return false;
  }
};

// If logged in → block access to login/register
const PublicRoute = ({ children }) => {
  if (isAuthenticated()) {
    return <Navigate to="/chat" replace />;
  }
  return children;
};

// If not logged in → block access to chat
const ProtectedRoute = ({ children }) => {
  if (!isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Root redirect - will go to login or chat based on auth status */}
        <Route 
          path="/" 
          element={
            isAuthenticated() ? 
            <Navigate to="/chat" replace /> : 
            <Navigate to="/login" replace />
          } 
        />

        <Route 
          path="/login" 
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          } 
        />

        <Route 
          path="/register" 
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          } 
        />

        <Route 
          path="/chat" 
          element={
            <ProtectedRoute>
              <Chat />
            </ProtectedRoute>
          } 
        />

        {/* Catch all - redirect to login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;